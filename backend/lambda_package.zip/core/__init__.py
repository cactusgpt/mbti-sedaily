"""
Core utilities module.
"""
