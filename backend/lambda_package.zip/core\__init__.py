"""
Core utilities module.
"""
